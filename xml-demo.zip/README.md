# XML Loading and Parsing Demo

This is a simple, lightweight demonstration of how to load and parse XML files using native JavaScript in the browser.

## Files Included
* **`data.xml`**: A well-structured XML file containing name, age, college, and address details.
* **`my-xml-demo.html`**: A lightweight webpage with JavaScript that fetches, parses, and displays the XML data.

## How to Run
Due to browser security policies (CORS), XML files cannot be loaded from the local file system directly (`file:///...`). You must run this using a local web server:

### Option 1: Python (Easiest)
1. Open your terminal/command prompt in this folder.
2. Run the following command:
   ```bash
   python -m http.server 8000
   ```
3. Open your browser and navigate to:
   ```
   http://localhost:8000/my-xml-demo.html
   ```

### Option 2: VS Code Live Server extension
If you use VS Code, install the **Live Server** extension, right-click `my-xml-demo.html`, and select **"Open with Live Server"**.
